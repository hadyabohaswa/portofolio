import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Mail, Linkedin, Github, Phone, MapPin, ExternalLink } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion"; // Import motion
import ThreeDBackground from '@/components/ThreeDBackground'; // Import ThreeDBackground

/**
 * Portfolio Design: Modern Professional Minimalism
 * - Asymmetric layout with hero section
 * - Deep slate-blue (#1a3a52) and vibrant teal (#00a8a8) color scheme
 * - Playfair Display for headings, Inter for body
 * - Vertical teal accent line connecting sections
 * - Timeline visualization for career progression
 */

export default function Home() {
  const [expandedExperience, setExpandedExperience] = useState<string | null>(null);

  const experiences = [
    {
      id: "lms-dev",
      title: "LMS Developer",
      company: "Digilians - الرواد الرقميون",
      period: "Oct 2025 - Present",
      type: "Part-time",
      location: "Cairo, Egypt (Hybrid)",
      description: "Install, configure, and maintain Moodle LMS instances on servers and Docker containers. Manage plugins, monitor system health, and optimize performance.",
      skills: ["Moodle", "Docker", "PHP", "MySQL", "System Administration"]
    },
    {
      id: "senior-moodle",
      title: "Senior Moodle Developer",
      company: "ECC Group",
      period: "Jun 2024 - Present",
      type: "Full-time",
      location: "Cairo, Egypt",
      description: "Develop custom Moodle themes, plugins, and integrations. Collaborate with instructional designers to optimize learning experiences. Manage databases and security.",
      skills: ["Moodle Development", "API Integration", "PHP", "WordPress", "Security"]
    },
    {
      id: "lms-specialist",
      title: "Learning Management System Senior Specialist",
      company: "Elsewedy Technical Academy",
      period: "Jun 2023 - Jun 2024",
      type: "Full-time",
      location: "Cairo, Egypt",
      description: "Built and maintained Moodle LMS infrastructure. Set performance goals, managed system updates, and provided technical support.",
      skills: ["Moodle Administration", "WordPress", "PHP", "Performance Optimization"]
    },
    {
      id: "lms-admin",
      title: "Senior LMS Administrator",
      company: "ESLSCA University",
      period: "2021 - 2023",
      type: "Full-time",
      location: "Cairo, Egypt",
      description: "Managed eLearning content in Moodle, administered online exams, and handled LMS back-office operations.",
      skills: ["Moodle", "Mettl", "Power Campus", "Dynamics 365", "Content Management"]
    }
  ];

  const skills = {
    "LMS & eLearning": ["Moodle", "IOMAD", "Mettl", "Online Assessment", "AI Proctoring"],
    "Web & Development": ["PHP", "WordPress", "HTML/CSS", "Docker", "Cloud Hosting"],
    "Databases & Tools": ["MySQL", "Oracle", "Power Campus", "Dynamics 365"],
    "Productivity": ["MS Office", "Photoshop", "Project Management", "Visio"],
    "Core Competencies": ["Digital Transformation", "Project Leadership", "HR Training", "Event Coordination"]
  };

  const education = [
    {
      degree: "MBA",
      school: "RB College, United Kingdom",
      period: "May 2024 - Present"
    },
    {
      degree: "Digital Transformation Diploma",
      school: "ESLSCA University, Egypt",
      period: "Nov 2021 - Present"
    },
    {
      degree: "Bachelor of Business Administration (BBA)",
      school: "Faculty of Commerce, Ain Shams University",
      period: "Graduated Jun 2011"
    }
  ];

  const fadeInVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-primary">Hady</div>
          <div className="flex gap-8">
            <a href="#experience" className="text-sm font-medium hover:text-accent transition-colors">Experience</a>
            <a href="#skills" className="text-sm font-medium hover:text-accent transition-colors">Skills</a>
            <a href="#education" className="text-sm font-medium hover:text-accent transition-colors">Education</a>
            <a href="#contact" className="text-sm font-medium hover:text-accent transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section with Accent Line */}
      <div className="relative">
        {/* Vertical accent line */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        <ThreeDBackground />
        
        <section className="relative pt-20 pb-20">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
              {/* Left side - Profile Image */}
              <div className="lg:col-span-2 flex justify-center">
                <div className="relative w-64 h-64 lg:w-72 lg:h-72">
                  <div className="absolute inset-0 bg-gradient-to-br from-accent to-accent/30 rounded-lg transform -rotate-6" />
                  <div className="absolute inset-0 bg-gradient-to-tl from-primary/20 to-transparent rounded-lg transform rotate-3" />
                  <img
                    src="/images/hero-bg.jpg"
                    alt="Hady Abo Haswa"
                    className="relative w-full h-full object-cover rounded-lg shadow-2xl"
                  />
                </div>
              </div>

              {/* Right side - Hero Text */}
              <div className="lg:col-span-3 space-y-6">
                <div className="space-y-2">
                  <p className="text-accent font-semibold text-sm tracking-widest uppercase">Welcome to my portfolio</p>
                  <motion.h1 
                    className="text-5xl lg:text-6xl font-bold text-primary leading-tight"
                    initial="hidden"
                    animate="visible"
                    variants={fadeInVariants}
                  >
                    Hady Abo Haswa
                  </motion.h1>
                  <motion.p 
                    className="text-2xl text-muted-foreground font-light"
                    initial="hidden"
                    animate="visible"
                    variants={fadeInVariants}
                    transition={{ delay: 0.2, duration: 0.6 }} // Add a slight delay for the job title
                  >
                    Senior Moodle & PHP Developer
                  </motion.p>
                </div>

                <p className="text-lg text-foreground/80 leading-relaxed max-w-xl">
                  Motivated professional with extensive experience in eLearning systems, project management, and digital transformation. Passionate about optimizing learning experiences and driving organizational growth through innovative technology solutions.
                </p>

                <div className="flex flex-wrap gap-3 pt-4">
                  <Badge variant="outline" className="px-4 py-2 text-sm">Moodle Expert</Badge>
                  <Badge variant="outline" className="px-4 py-2 text-sm">PHP Developer</Badge>
                  <Badge variant="outline" className="px-4 py-2 text-sm">Digital Transformation</Badge>
                  <Badge variant="outline" className="px-4 py-2 text-sm">Project Leader</Badge>
                </div>

                <div className="flex gap-4 pt-6">
                  <Button className="bg-primary hover:bg-primary/90 text-white">
                    <Mail className="w-4 h-4 mr-2" />
                    Get in Touch
                  </Button>
                  <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
                    <Linkedin className="w-4 h-4 mr-2" />
                    LinkedIn
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Experience Section */}
      <section id="experience" className="relative py-20 bg-secondary/30">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Professional Experience</h2>

          <div className="space-y-6">
            {experiences.map((exp, idx) => (
              <Card
                key={exp.id}
                className="p-6 border-l-4 border-l-accent hover:shadow-lg transition-all cursor-pointer"
                onClick={() => setExpandedExperience(expandedExperience === exp.id ? null : exp.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-2xl font-semibold text-primary">{exp.title}</h3>
                      <span className="text-xs font-medium px-3 py-1 bg-accent/10 text-accent rounded-full">
                        {exp.type}
                      </span>
                    </div>
                    <p className="text-lg font-medium text-accent mb-1">{exp.company}</p>
                    <div className="flex gap-4 text-sm text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {exp.location}
                      </span>
                      <span>{exp.period}</span>
                    </div>
                    
                    {expandedExperience === exp.id && (
                      <div className="mt-4 space-y-4 animate-in fade-in duration-300">
                        <p className="text-foreground/80 leading-relaxed">{exp.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {exp.skills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="text-accent ml-4">
                    {expandedExperience === exp.id ? "−" : "+"}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="relative py-20">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Skills & Expertise</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Object.entries(skills).map(([category, skillList]) => (
              <Card key={category} className="p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-primary mb-4">{category}</h3>
                <div className="flex flex-wrap gap-2">
                  {skillList.map((skill) => (
                    <Badge
                      key={skill}
                      variant="outline"
                      className="border-accent text-accent hover:bg-accent/10 cursor-default"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="relative py-20 bg-secondary/30">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Education</h2>

          <div className="space-y-6">
            {education.map((edu, idx) => (
              <Card key={idx} className="p-6 border-l-4 border-l-accent">
                <h3 className="text-2xl font-semibold text-primary mb-2">{edu.degree}</h3>
                <p className="text-lg text-accent font-medium mb-1">{edu.school}</p>
                <p className="text-sm text-muted-foreground">{edu.period}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative py-20">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        
        <div className="container">
          <h2 className="text-4xl font-bold text-primary mb-12">Get In Touch</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Mail className="w-8 h-8 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">Email</h3>
              <a href="mailto:Hady.smile@gmail.com" className="text-accent hover:underline">
                Hady.smile@gmail.com
              </a>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Phone className="w-8 h-8 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">Phone</h3>
              <a href="tel:+201001825581" className="text-accent hover:underline">
                +20 100 182 5581
              </a>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Linkedin className="w-8 h-8 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-primary mb-2">LinkedIn</h3>
              <a href="https://www.linkedin.com/in/hady-abo-haswa/" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline flex items-center justify-center gap-2">
                Connect
                <ExternalLink className="w-4 h-4" />
              </a>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative border-t border-border bg-secondary/50 py-8">
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-accent to-accent/30" />
        
        <div className="container text-center text-muted-foreground text-sm">
          <p>© 2025 Hady Abo Haswa. All rights reserved.</p>
          <p className="mt-2">Based in Cairo, Egypt | Open to opportunities</p>
        </div>
      </footer>
    </div>
  );
}
